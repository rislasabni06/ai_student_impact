"""
train_model.py
---------------
One-time / re-runnable training script for the AI Student Impact
Post-Semester GPA predictor.

Run this whenever you update ai_student_impact_dataset.csv to
regenerate model.pkl.

Usage:
    python train_model.py
"""

import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Burnout_Risk_Level is mapped explicitly (NOT via a fitted LabelEncoder)
# so the mapping never silently changes between training runs or datasets.
# This matches sklearn's LabelEncoder's alphabetical ordering for this
# dataset's three categories: High < Low < Medium.
BURNOUT_MAP = {"High": 0, "Low": 1, "Medium": 2}

FEATURE_COLUMNS = [
    "Weekly_GenAI_Hours",
    "Traditional_Study_Hours",
    "Skill_Retention_Score",
    "Anxiety_Level_During_Exams",
    "Perceived_AI_Dependency",
    "Pre_Semester_GPA",
    "Burnout_Risk_Level",
]
TARGET_COLUMN = "Post_Semester_GPA"


def load_and_prepare(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df["Burnout_Risk_Level"] = df["Burnout_Risk_Level"].map(BURNOUT_MAP)
    return df


def train(csv_path: str = "ai_student_impact_dataset.csv", model_out: str = "model.pkl"):
    df = load_and_prepare(csv_path)

    x = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]

    # Drop any rows with NaNs in the columns we actually use
    combined = pd.concat([x, y], axis=1).dropna()
    x = combined[FEATURE_COLUMNS]
    y = combined[TARGET_COLUMN]

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42
    )

    model = LinearRegression()
    model.fit(x_train, y_train)

    train_r2 = model.score(x_train, y_train)
    test_r2 = model.score(x_test, y_test)

    print(f"Train R^2: {train_r2:.4f}")
    print(f"Test  R^2: {test_r2:.4f}")
    print("Coefficients:")
    for col, coef in zip(FEATURE_COLUMNS, model.coef_):
        print(f"  {col:30s} {coef:+.6f}")
    print(f"Intercept: {model.intercept_:+.6f}")

    joblib.dump(
        {
            "model": model,
            "feature_columns": FEATURE_COLUMNS,
            "burnout_map": BURNOUT_MAP,
            "train_r2": train_r2,
            "test_r2": test_r2,
        },
        model_out,
    )
    print(f"\nSaved model bundle to {model_out}")


if __name__ == "__main__":
    train()
