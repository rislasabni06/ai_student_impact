# AI Student Impact — Backend (Flask API)

A small Flask REST API that serves predictions from a linear regression
model trained to estimate a student's **Post-Semester GPA** based on
GenAI usage habits, study habits, and other factors.

This was converted from an original Streamlit prototype into a
proper frontend/backend split so the frontend (static HTML/CSS/JS) can
be deployed separately on Vercel while this API runs on a platform
that supports long-running Python processes.

## Why not Vercel for this part?

Vercel's Python support is serverless-function based — it's a poor fit
for a scikit-learn model server with file-based model loading and no
persistent process. This backend is meant to be deployed to a platform
built for that, such as **Render**, **Railway**, **Fly.io**, or
**Hugging Face Spaces**. The instructions below use Render as the
default, since it has the simplest free-tier setup for Flask + sklearn.

## Project structure

```
backend/
├── app.py                          # Flask routes
├── utils.py                        # model loading + prediction logic
├── train_model.py                  # one-time training script
├── model.pkl                       # trained model bundle (generated)
├── ai_student_impact_dataset.csv   # training data
├── requirements.txt
├── Procfile                        # for Render/Heroku-style deploys
└── .gitignore
```

## Local setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### (Re)train the model

Only needed if you change the dataset or want to regenerate `model.pkl`:

```bash
python train_model.py
```

This prints train/test R² and writes `model.pkl`.

### Run the API locally

```bash
python app.py
```

The API will be live at `http://localhost:5000`.

## API reference

### `GET /api/health`
Returns `{"status": "ok"}` if the model loaded successfully.

### `GET /api/metrics`
Returns the model's train/test R² scores.

```json
{ "train_r2": 0.8826, "test_r2": 0.8829 }
```

### `POST /api/predict`

Request body (all fields required):

```json
{
  "Weekly_GenAI_Hours": 10,
  "Traditional_Study_Hours": 12,
  "Skill_Retention_Score": 75,
  "Anxiety_Level_During_Exams": 5,
  "Perceived_AI_Dependency": 4,
  "Pre_Semester_GPA": 3.5,
  "Burnout_Risk_Level": "Medium"
}
```

`Burnout_Risk_Level` must be one of `"Low"`, `"Medium"`, `"High"`.

Successful response:

```json
{ "predicted_post_semester_gpa": 3.7 }
```

Error response (400):

```json
{ "error": "Field 'Pre_Semester_GPA' must be between 0.0 and 4.0." }
```

## Deploying to Render (recommended)

1. Push this repo to GitHub (see root `README.md` for the full repo layout).
2. Go to [render.com](https://render.com) → **New** → **Web Service**.
3. Connect your GitHub repo, and set:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
4. Add an environment variable (after you know your Vercel URL):
   - `FRONTEND_ORIGIN` = `https://your-app.vercel.app`
5. Deploy. Render will give you a URL like
   `https://ai-student-impact-api.onrender.com`.
6. Put that URL into the frontend's `script.js`
   (`API_BASE_URL` constant) before deploying the frontend.

### Note on Render's free tier

Free Render web services spin down after periods of inactivity and take
~30–60 seconds to "wake up" on the next request. The frontend's loading
state accounts for this, but if it feels broken on first load, that's
why — just wait and retry.

## Deploying elsewhere

- **Railway**: similar to Render — set root directory to `backend`,
  build command `pip install -r requirements.txt`, start command
  `gunicorn app:app`.
- **Hugging Face Spaces** (Docker SDK): add a `Dockerfile` that installs
  `requirements.txt` and runs `gunicorn app:app -b 0.0.0.0:7860`.
- **Vercel serverless** (advanced/optional): possible but requires
  restructuring `app.py` as a serverless function handler and watching
  the deployment size limit (scikit-learn + pandas + numpy can exceed
  Vercel's bundle size on the free tier). Not recommended for this app.
